package controllers

import "github.com/jgraham909/revmgo"

func init() {
	revmgo.ControllerInit()
}
